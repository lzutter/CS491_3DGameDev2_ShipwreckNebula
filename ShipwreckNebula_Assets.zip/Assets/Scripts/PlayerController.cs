﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    private new Rigidbody rigidbody;
    public float speed;
    public GameObject howToPlay;

    //NOTE: might have gravity issues.

    // Use this for initialization
    void Start()
    {
        rigidbody = gameObject.GetComponent<Rigidbody>();
    }

    //For controled update based triggers such as character movement
    void FixedUpdate()
    {
        //controls forward and backward rigidbody movement
        //float movement = Input.GetAxis("Vertical"); //This isn't actually used
        if (Input.GetKey("w"))
        {
            speed = 5;
        }
        else if (Input.GetKey("s"))
        {
            speed = -5;
        }
        else {
            speed = 0;
        }

        //controls rigidbody left/right facing
        if (Input.GetKey("a"))
        {
            rigidbody.AddTorque(0, -3, 0);
        }
        else if (Input.GetKey("d"))
        {
            rigidbody.AddTorque(0, 3, 0);
        }

        //applies movement
        Vector3 forward = transform.forward; //gets the current facing. Note: if the forward facing isn't the model's forward facing, rotate it in te 3d modeler
        forward.y = 0; //disallows going up and down (that would be unintended in this game)
        forward *= speed; //amplifies the forward vector to reflect current speed
        rigidbody.velocity = forward; //application of movement
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("h"))
        {
            bool active;
            if (howToPlay.activeInHierarchy == true)
            {
                active = false;
            }
            else {
                active = true;
            }
            howToPlay.SetActive(active);
        }
    }
}
