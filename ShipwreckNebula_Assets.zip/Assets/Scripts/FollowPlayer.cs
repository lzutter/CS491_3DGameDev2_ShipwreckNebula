﻿using UnityEngine;
using System.Collections;

public class FollowPlayer : MonoBehaviour {

    NavMeshAgent agent;
    public Transform target;
    public bool approach;
    public AudioClip response;
    public AudioClip near;
    private AudioSource source;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        source = GetComponent<AudioSource>();
    }
    
    void OnTriggerEnter(Collider obj) {
        if(obj.tag == "NavCollider") {
            approach = false;
            source.PlayOneShot(near);
        }
    }

    void OnTriggerExit(Collider obj) {
        if(obj.tag == "NavCollider") {
            approach = true;
        }
    }
    
    void Update()
    {
        //turns buddybot movement on and off
        if (approach) {
            agent.SetDestination(target.position);
        } else {
            agent.SetDestination(transform.position);
        }

        //plays buddybot's response sound (assigned in Unity)
        if (Input.GetKeyDown("c")) {
            source.PlayOneShot(response);
        }
    }
}
